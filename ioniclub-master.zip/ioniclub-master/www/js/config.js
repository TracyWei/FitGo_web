angular.module("ioniclub.config", [])
    .constant("ENV", {
        // "name": "production",
        "accessToken": '',
        "debug": false,
        "api": "http://ionichina.com/api/v1",
        // "api": "http://localhost:3000/api/v1",
        "appleId": 'id981408438',
        'version':'1.0.1'
    })
;
